<template>
  <div class="max-w-4xl mx-auto py-16 px-4">
    <h2 class="text-3xl font-semibold text-center mb-8">Sobre Mim</h2>

    <p class="text-lg mb-6">
      Olá, meu nome é <strong>João Pedro</strong>, sou um desenvolvedor front-end dedicado em criar soluções inovadoras e funcionais para a web. Com um grande interesse por tecnologia e design, busco sempre aprimorar minhas habilidades e aprender novas ferramentas para oferecer a melhor experiência para os usuários.
    </p>

    <p class="text-lg mb-6">
      iniciei minha carreira na tecnologia ainda jovem, explorando a programação por curiosidade. Desde então, me dediquei em criar interfaces intuitivas e visuais. O que levou a me especializar no desenvolvimento front-end. Ao longo dos anos, adquiri experiência trabalhando com várias tecnologias, incluindo Vue.js, JavaScript, Tailwind CSS e outras ferramentas modernas que ajudam a transformar ideias em soluções reais e eficientes.
    </p>

    <h3 class="text-2xl font-semibold mt-8 mb-4">Habilidades</h3>
    <ul class="list-disc pl-5 text-lg mb-6">
      <li><strong>Vue.js</strong>: Framework JavaScript que utilizo para criar interfaces dinâmicas e escaláveis.</li>
     
      <li><strong>JavaScript</strong>: Linguagem principal para desenvolvimento de interatividade na web.</li>
      
      <li><strong>HTML5 & CSS3</strong>: Bases do desenvolvimento web, sempre aplicando boas práticas de acessibilidade e responsividade.</li>
      
      <li><strong>Tailwind CSS</strong>: Biblioteca de estilos que permite criar layouts rápidos e eficientes, com design responsivo e moderno.</li>
      
      <li><strong>Git</strong>: Controle de versão e colaboração com equipes, garantindo que o código seja bem gerenciado e organizado.</li>
    </ul>

    <h3 class="text-2xl font-semibold mb-4">Formação</h3>
    <p class="text-lg mb-6">
      Sou formado em <strong>Análise e Desenvolvimento de Sistemas</strong> pela <strong>Universidade de Marília - Unimar</strong>, onde pude adquirir uma sólida base teórica sobre algoritmos, estruturas de dados e sistemas computacionais. Durante a faculdade, participei de diversos projetos acadêmicos e extracurriculares, o que me proporcionou uma experiência prática valiosa.
    </p>

    <h3 class="text-2xl font-semibold mb-4">Minha Trajetória</h3>
    <p class="text-lg mb-6">
      Desde o início da minha carreira, venho me dedicando a melhorar minhas habilidades em desenvolvimento web. Trabalhei em diversas empresas e projetos, onde pude colaborar com equipes incríveis, aprender novas tecnologias e contribuir para a criação de sites e aplicações inovadoras.
    </p>

    <p class="text-lg">
      Estou sempre em busca de novos desafios e oportunidades para crescer como profissional e como pessoa. Acredito que a chave para o sucesso está em aprender constantemente e aplicar esse conhecimento para resolver problemas reais.
    </p>
  </div>
</template>

<script setup>

</script>